#include QMK_KEYBOARD_H

bool encoder_update_kb(uint8_t index, bool clockwise) {
    if (index == 0) { /* First encoder */
        if (clockwise) {
            tap_code(KC_Q);
        } else {
            tap_code(KC_W);
        }
    } else if (index == 1) { /* Second encoder */
        if (clockwise) {
            tap_code(KC_O);
        } else {
            tap_code(KC_P);
        }
    }

    return true;
}

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

[0] =	LAYOUT_a(
		KC_T,
		KC_D, KC_F, KC_J, KC_K,
		KC_C, KC_M)
};
